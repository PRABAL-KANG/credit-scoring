```markdown

# Wallet Score Analysis

## Score Distribution
- 0–100: X wallets
- 100–200: Y wallets
...
- 900–1000: Z wallets

(Include histogram here after real data)

## Low Score Behavior
- High liquidation counts
- Low repay-to-borrow ratio
- Few deposits

## High Score Behavior
- Frequent deposits
- High repay ratio
- Zero liquidations
