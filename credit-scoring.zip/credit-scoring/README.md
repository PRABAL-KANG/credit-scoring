# Aave V2 Wallet Credit Scoring

## Overview
This project assigns credit scores (0–1000) to wallets based on transaction behavior using Aave V2 data.

## How it works
- Parses JSON file of user transactions
- Extracts behavioral features like deposits, borrows, liquidations
- Applies a rule-based scoring logic

## Features Used
- Total deposits/borrows/repays
- Repay-to-borrow ratio
- Liquidation count

## Scoring Logic
Score = 500 + reward for good behavior - penalty for risk  
Capped between 0 and 1000.

## Run the Project
```bash
python src/score_generator.py data/user_transactions.json
