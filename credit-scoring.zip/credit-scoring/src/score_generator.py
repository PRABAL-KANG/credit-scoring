import json
import pandas as pd
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from feature_engineering import extract_features

def calculate_score(row):
    score = 500
    score += min(row["total_deposit"] * 0.01, 100)
    score += min(row["repay_to_borrow_ratio"] * 200, 200)
    score -= row["liquidation_count"] * 50
    score = max(0, min(1000, score))
    return round(score)

def main(json_path):
    with open(json_path, "r") as f:
        raw_data = json.load(f)

    tx_df = pd.DataFrame(raw_data)
    tx_df["amount"] = tx_df["amount"].astype(float)

    features_df = extract_features(tx_df)
    features_df["score"] = features_df.apply(calculate_score, axis=1)
    features_df[["wallet", "score"]].to_csv("score_output.csv", index=False)

if __name__ == "__main__":
    import sys
    main(sys.argv[1])
